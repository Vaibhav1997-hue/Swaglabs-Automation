package Extentreport;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import junit.framework.Assert;

public class Extentreport1 {
	WebDriver driver;

	ExtentSparkReporter htmlReporter;
	ExtentReports reports;
	ExtentTest test;

	@BeforeTest
	public void startreport() {
		htmlReporter = new ExtentSparkReporter("ExtentReport.html");
		reports = new ExtentReports();
		reports.attachReporter(htmlReporter);

		// add enviroment details
		reports.setSystemInfo("machine", "laptop");
		reports.setSystemInfo("OS", "Windows 11");
		reports.setSystemInfo("user", "Vaibhav");
		reports.setSystemInfo("Browser", "Chrome");

		// Configure to change look
		htmlReporter.config().setDocumentTitle("Extent Report");
		htmlReporter.config().setReportName("Test Report");
		htmlReporter.config().setTheme(Theme.STANDARD);
		htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
	}

	@Test
	public void VerifyLaunchBrowserandopenurl() {
		test = reports.createTest("Verify Launch browser and open URL");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Assert.assertTrue(true); // Test Passed

	}

	@Test
	public void VerifyLogin() throws InterruptedException {
		test = reports.createTest("Verify Login with valid credential");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Assert.assertTrue(true); // Test Passed

	}

	@Test
	public void VerifyHomepageLoadafterLogin() throws InterruptedException {
		test = reports.createTest("Verify Homepage Load after Login");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		WebElement productsTitle = driver.findElement(By.xpath("//div[text()='Products']"));
		Assert.assertTrue(productsTitle.isDisplayed());

		Assert.assertTrue(true); // Test Passed

	}

	@Test
	public void Verifyproductfiltering() throws InterruptedException {
		test = reports.createTest("Verify Product Filtering (Low to High Price) works correctly.");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//div[@id='inventory_filter_container']//select[1]"));
		Select select = new Select(dropdown);

		// Select by visible text
		select.selectByVisibleText("Price (low to high)");
		Thread.sleep(5000);
		Assert.assertTrue(true); // Test Passed
	}

	@Test
	public void Verifyprintlistofproduct() throws InterruptedException {
		test = reports.createTest("Verify Extract and print the list of product names after filtering.");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//div[@id='inventory_filter_container']//select[1]"));
		Select select = new Select(dropdown);

		// Select by visible text
		select.selectByVisibleText("Price (low to high)");
		Thread.sleep(5000);

		List<WebElement> productNames = driver.findElements(By.xpath("//*[@id=\"inventory_container\"]/div"));

		// Print product names
		for (WebElement product : productNames) {
			System.out.println(product.getText());

			Assert.assertTrue(true); // Test Passed

		}
	}

	@Test
	public void VerifySelectproductfromfilteredlist() throws InterruptedException {
		test = reports.createTest("Verify Select a product from the filtered list.");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//div[@id='inventory_filter_container']//select[1]"));
		Select select = new Select(dropdown);

		// Select by visible text
		select.selectByVisibleText("Price (low to high)");
		Thread.sleep(5000);
		// click on product
		driver.findElement(By.xpath("//a[@href='./inventory-item.html?id=2']//div[1]")).click();
		Assert.assertTrue(true); // Test Passed

	}

	@Test
	public void VerifyAddtheselectedproducttothecart() throws InterruptedException {
		test = reports.createTest("Verify Add the selected product to the cart.");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//div[@id='inventory_filter_container']//select[1]"));
		Select select = new Select(dropdown);

		// Select by visible text
		select.selectByVisibleText("Price (low to high)");
		Thread.sleep(5000);
		// click on product
		driver.findElement(By.xpath("//a[@href='./inventory-item.html?id=2']//div[1]")).click();
		Thread.sleep(5000);
		// Step 3: Get product name before adding to cart
		WebElement product = driver.findElement(By.xpath("//div[text()='Sauce Labs Onesie']"));
		String expectedProductName = product.getText();
		System.out.println("Product name " + expectedProductName);
		Thread.sleep(5000);
		// Step 4: Add the product to cart
		driver.findElement(By.xpath("//button[@class='btn_primary btn_inventory']")).click();

		Assert.assertTrue(true); // Test Passed

	}

	@Test
	public void Verifythattheproductissuccessfullyaddedtothecart() throws InterruptedException {
		test = reports.createTest("Verify that the product is successfully added to the cart..");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//div[@id='inventory_filter_container']//select[1]"));
		Select select = new Select(dropdown);

		// Select by visible text
		select.selectByVisibleText("Price (low to high)");
		Thread.sleep(5000);
		// click on product
		driver.findElement(By.xpath("//a[@href='./inventory-item.html?id=2']//div[1]")).click();
		Thread.sleep(5000);
		// Step 3: Get product name before adding to cart
		WebElement product = driver.findElement(By.xpath("//div[text()='Sauce Labs Onesie']"));
		String expectedProductName = product.getText();
		System.out.println("Product name " + expectedProductName);
		Thread.sleep(5000);
		// Step 4: Add the product to cart
		driver.findElement(By.xpath("//button[@class='btn_primary btn_inventory']")).click();
		Thread.sleep(5000);

		Assert.assertTrue(true); // Test Passed

	}

	@Test
	public void Verifycheckoutprocess() throws InterruptedException {
		test = reports.createTest("Verify Proceed to checkout.");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);

		// Select product and add to cart
		driver.findElement(By.xpath("//div[text()='Sauce Labs Bolt T-Shirt']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='ADD TO CART']")).click();
		Thread.sleep(2000);

		// click on cart
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[2]/a[1]/*[name()='svg'][1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='btn_action checkout_button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='form_input']")).sendKeys("Vaibhav");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form_input'])[2]")).sendKeys("Khondekar");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form_input'])[3]")).sendKeys("441111");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='btn_primary cart_button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='btn_action cart_button']")).click();

		WebElement confirmationMessage = driver.findElement(By.xpath("//h2[text()='THANK YOU FOR YOUR ORDER']"));
		String actualMessage = confirmationMessage.getText();
		String expectedMessage = "THANK YOU FOR YOUR ORDER";
		Assert.assertTrue(true); // Test Passed

	}

	@Test
	public void VerifyFillinrequireddetails() throws InterruptedException {
		test = reports.createTest("Verify Fill in required details");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);

		// Select product and add to cart
		driver.findElement(By.xpath("//div[text()='Sauce Labs Bolt T-Shirt']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='ADD TO CART']")).click();
		Thread.sleep(2000);

		// click on cart
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[2]/a[1]/*[name()='svg'][1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='btn_action checkout_button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='form_input']")).sendKeys("Vaibhav");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form_input'])[2]")).sendKeys("Khondekar");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form_input'])[3]")).sendKeys("441111");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='btn_primary cart_button']")).click();

		Assert.assertTrue(true); // Test Passed
	}

	@Test
	public void VerifyCompletethepurchaseprocess() throws InterruptedException {
		test = reports.createTest("Verify Complete the purchase process.");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);

		// Select product and add to cart
		driver.findElement(By.xpath("//div[text()='Sauce Labs Bolt T-Shirt']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='ADD TO CART']")).click();
		Thread.sleep(2000);

		// click on cart
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[2]/a[1]/*[name()='svg'][1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='btn_action checkout_button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='form_input']")).sendKeys("Vaibhav");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form_input'])[2]")).sendKeys("Khondekar");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form_input'])[3]")).sendKeys("441111");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='btn_primary cart_button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='btn_action cart_button']")).click();

		WebElement confirmationMessage = driver.findElement(By.xpath("//h2[text()='THANK YOU FOR YOUR ORDER']"));
		String actualMessage = confirmationMessage.getText();
		String expectedMessage = "THANK YOU FOR YOUR ORDER";
		Thread.sleep(3000);
		Assert.assertTrue(true); // Test Passed

	}

	@Test
	public void Verifyorderconfirmationorsuccessmessage() throws InterruptedException {
		test = reports.createTest("Verify Assert the order confirmation or success message.");
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);

		// Select product and add to cart
		driver.findElement(By.xpath("//div[text()='Sauce Labs Bolt T-Shirt']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='ADD TO CART']")).click();
		Thread.sleep(2000);

		// click on cart
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[2]/a[1]/*[name()='svg'][1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='btn_action checkout_button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='form_input']")).sendKeys("Vaibhav");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form_input'])[2]")).sendKeys("Khondekar");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form_input'])[3]")).sendKeys("441111");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='btn_primary cart_button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='btn_action cart_button']")).click();

		WebElement confirmationMessage = driver.findElement(By.xpath("//h2[text()='THANK YOU FOR YOUR ORDER']"));
		String actualMessage = confirmationMessage.getText();
		String expectedMessage = "THANK YOU FOR YOUR ORDER";
		Assert.assertTrue(true); // Test Passed

	}

	@AfterMethod
	public void getTestResult(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + "FAILED", ExtentColor.RED));
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + "PASSED", ExtentColor.GREEN));
		} else if (result.getStatus() == ITestResult.SKIP) {
			test.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + "SKIPPED", ExtentColor.YELLOW));
		}
	}

	@AfterTest
	public void teardown() {
		reports.flush();
	}
}
