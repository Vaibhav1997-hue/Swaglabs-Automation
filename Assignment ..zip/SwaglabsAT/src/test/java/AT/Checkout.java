package AT;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Checkout {

	WebDriver driver;

	@Test
	public void checkoutprocess() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);

		// Select product and add to cart
		driver.findElement(By.xpath("//div[text()='Sauce Labs Bolt T-Shirt']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='ADD TO CART']")).click();
		Thread.sleep(2000);

		// click on cart
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[2]/a[1]/*[name()='svg'][1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='btn_action checkout_button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='form_input']")).sendKeys("Vaibhav");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form_input'])[2]")).sendKeys("Khondekar");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form_input'])[3]")).sendKeys("441111");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='btn_primary cart_button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='btn_action cart_button']")).click();

		WebElement confirmationMessage = driver.findElement(By.xpath("//h2[text()='THANK YOU FOR YOUR ORDER']"));
		String actualMessage = confirmationMessage.getText();
		String expectedMessage = "THANK YOU FOR YOUR ORDER";
		Thread.sleep(3000);
		driver.close();
	}

}
