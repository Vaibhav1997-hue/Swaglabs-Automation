package AT;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Loginwithhomepagedisplay {
	WebDriver driver;

	@DataProvider(name = "users")
	public Object[][] Data() {
		return new Object[][] { { "standard_user", "secret_sauce" }, { "problem_user", "secret_sauce" },
				{ "performance_glitch_user", "secret_sauce" },

		};

	}

	@Test(dataProvider = "users") // Perform login using valid credentials.
	public void multipleUserLoging(String user, String password) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]")).sendKeys(user);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys(password);
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		// Assert that the homepage is displayed.
		WebElement productsTitle = driver.findElement(By.xpath("//div[text()='Products']"));
		Assert.assertTrue(productsTitle.isDisplayed(), "Homepage is not displayed - Products title missing.");

		driver.close();

	}

}
