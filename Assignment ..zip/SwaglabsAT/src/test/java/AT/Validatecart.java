package AT;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Validatecart {
	WebDriver driver;

	@Test // Select a product from the filtered list.
	public void Selectproduct() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100); // Login
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//div[@id='inventory_filter_container']//select[1]"));
		Select select = new Select(dropdown);

		select.selectByVisibleText("Price (low to high)");
		// Select a product from the filtered list.
		driver.findElement(By.xpath("//div[text()='Sauce Labs Onesie']")).click();
		Thread.sleep(5000);
		driver.close();

	}

	@Test // Add the selected product to the cart.
	public void addproduct() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//div[@id='inventory_filter_container']//select[1]"));
		Select select = new Select(dropdown);

		select.selectByVisibleText("Price (low to high)");
		// Select a product from the filtered list.
		driver.findElement(By.xpath("//div[text()='Sauce Labs Onesie']")).click(); //
		// Add the selected product to the cart.
		driver.findElement(By.xpath("//button[@class='btn_primary btn_inventory']")).click();
		Thread.sleep(5000);
		driver.close();
	}

	@Test // Assert that the product is successfully added to the cart..
	public void validateproduct() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//div[@id='inventory_filter_container']//select[1]"));
		Select select = new Select(dropdown);

		// Select by visible text
		select.selectByVisibleText("Price (low to high)");
		Thread.sleep(5000);
		// click on product
		driver.findElement(By.xpath("//a[@href='./inventory-item.html?id=2']//div[1]")).click();
		Thread.sleep(5000);
		// Step 3: Get product name before adding to cart
		WebElement product = driver.findElement(By.xpath("//div[text()='Sauce Labs Onesie']"));
		String expectedProductName = product.getText();
		System.out.println("Product name " + expectedProductName);
		Thread.sleep(5000);
		// Step 4: Add the product to cart
		driver.findElement(By.xpath("//button[@class='btn_primary btn_inventory']")).click();
		Thread.sleep(5000);
		// Click on cart
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[2]/a[1]/*[name()='svg'][1]")).click();
		Thread.sleep(5000);
		// Get the product name in cart
		WebElement cartProduct = driver
				.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[3]/div[2]/a[1]/div[1]"));
		String actualProductName = cartProduct.getText();
		Assert.assertEquals(actualProductName, expectedProductName,
				"❌ Product mismatch! Expected: " + expectedProductName + " | Actual: " + actualProductName);

		System.out.println("✅ Product added to cart successfully: " + actualProductName);

		Thread.sleep(5000);

	}

}
