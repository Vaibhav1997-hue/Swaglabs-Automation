package AT;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Productfiltering {
	WebDriver driver;

	@Test // Apply the filter: Sort by Price – Low to High.
	public void sorting() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//div[@id='inventory_filter_container']//select[1]"));
		Select select = new Select(dropdown);

		// Select by visible text
		select.selectByVisibleText("Price (low to high)");
		driver.close();

	}

	@Test // Extract and Print the list of product name after filtering
	public void print() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\java\\SwaglabsAT\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		Thread.sleep(100);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[1]"))
				.sendKeys("standard_user");
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[2]"))
				.sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/form[1]/input[3]")).click();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//div[@id='inventory_filter_container']//select[1]"));
		Select select = new Select(dropdown);

		// Select by visible text
		select.selectByVisibleText("Price (low to high)");
		Thread.sleep(5000);
		List<WebElement> productNames = driver.findElements(By.xpath("//*[@id=\"inventory_container\"]/div"));

		// Print product names
		for (WebElement product : productNames) {
			System.out.println(product.getText());

		}
		Thread.sleep(5000);
		driver.close();
	}
}
